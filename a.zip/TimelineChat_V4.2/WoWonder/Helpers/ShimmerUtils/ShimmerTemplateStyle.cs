﻿namespace WoWonder.Helpers.ShimmerUtils
{
    public enum ShimmerTemplateStyle
    {
        PostTemplate = 0,
        NotificationTemplate = 1
    }
}