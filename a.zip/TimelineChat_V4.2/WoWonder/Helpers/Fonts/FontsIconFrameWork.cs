﻿namespace WoWonder.Helpers.Fonts
{
    public enum FontsIconFrameWork
    {
        IonIcons,
        FontAwesomeSolid,
        FontAwesomeRegular,
        FontAwesomeBrands,
        FontAwesomeLight,
        FontAwesomeDuotone,
        FontAwesomeThin,
        FontAwesomeV4Compatibility,
    }
}