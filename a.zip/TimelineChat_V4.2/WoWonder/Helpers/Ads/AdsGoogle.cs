﻿using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.Gms.Maps;
using Android.Util;
using Android.Views;
using AndroidX.RecyclerView.Widget;
using Anjo.Android.GoogleAds;
using Com.Google.Android.Gms.Ads;
using Com.Google.Android.Gms.Ads.Admanager;
using Com.Google.Android.Gms.Ads.Appopen;
using Com.Google.Android.Gms.Ads.Initialization;
using Com.Google.Android.Gms.Ads.Interstitial;
using Com.Google.Android.Gms.Ads.Nativead;
using Com.Google.Android.Gms.Ads.Rewarded;
using Com.Google.Android.Gms.Ads.Rewardedinterstitial;
using System;
using System.Collections.Generic;
using WoWonder.Helpers.Model;
using WoWonder.Helpers.Utils;
using Exception = System.Exception;
using NativeAd = Com.Google.Android.Gms.Ads.Nativead.NativeAd;
using Object = Java.Lang.Object;

namespace WoWonder.Helpers.Ads
{
    public static class AdsGoogle
    {
        private static int CountInterstitial;
        private static int CountRewarded;
        private static int CountAppOpen;
        private static int CountRewardedInterstitial;

        #region Interstitial

        private class AdMobInterstitial : AnjoInterstitialLoadCallback
        {
            private Activity ActivityContext;

            public void Show(Activity context)
            {
                try
                {
                    ActivityContext = context;
                    var requestBuilder = new AdRequest.Builder().Build();
                    InterstitialAd.Load(context, AppSettings.AdInterstitialKey, requestBuilder, this);
                }
                catch (Exception exception)
                {
                    Methods.DisplayReportResultTrack(exception);
                }
            }

            public override void OnAdLoaded(InterstitialAd p0)
            {
                try
                {
                    p0?.Show(ActivityContext);
                    base.OnAdLoaded(p0);
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                Log.Debug("Google-Ads", "I_Ad AdMobInterstitial Load Failed: " + p0.Message);
                base.OnAdFailedToLoad(p0);
            }
        }

        public static void Ad_Interstitial(Activity context)
        {
            try
            {
                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobInterstitial)
                {
                    case true:
                        {
                            if (CountInterstitial == AppSettings.ShowAdInterstitialCount)
                            {
                                CountInterstitial = 0;
                                AdMobInterstitial ads = new AdMobInterstitial();
                                ads.Show(context);
                            }
                            else
                            {
                                Ad_AppOpenManager(context);
                            }

                            CountInterstitial++;
                            break;
                        }
                    default:
                        Ad_AppOpenManager(context);
                        break;
                }
            }
            catch (Exception exception)
            {
                Methods.DisplayReportResultTrack(exception);
            }
        }

        #endregion

        #region Native

        private class AdMobNative : AdListener, NativeAd.IOnNativeAdLoadedListener
        {
            private TemplateView Template;
            private Activity Context;
            public void ShowAd(Activity context, TemplateView template = null)
            {
                try
                {
                    Context = context;

                    Template = template ?? Context.FindViewById<TemplateView>(Resource.Id.my_template);
                    if (Template != null)
                    {
                        Template.Visibility = ViewStates.Gone;

                        switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobNative)
                        {
                            case true:
                                {
                                    AdLoader.Builder builder = new AdLoader.Builder(Context, AppSettings.AdAdMobNativeKey);
                                    builder.ForNativeAd(this);
                                    VideoOptions videoOptions = new VideoOptions.Builder()
                                        .SetStartMuted(true)
                                        .Build();
                                    NativeAdOptions adOptions = new NativeAdOptions.Builder()
                                        .SetVideoOptions(videoOptions)
                                        .Build();

                                    builder.WithNativeAdOptions(adOptions);

                                    AdLoader adLoader = builder.WithAdListener(this).Build();
                                    adLoader.LoadAd(new AdRequest.Builder().Build());
                                    break;
                                }
                            default:
                                Template.Visibility = ViewStates.Gone;
                                break;
                        }
                    }
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public void OnNativeAdLoaded(NativeAd ad)
            {
                try
                {
                    NativeTemplateStyle styles = new NativeTemplateStyle.Builder().Build();

                    if (Template.GetTemplateTypeName() == TemplateView.NativeContentAd)
                    {
                        Template.NativeContentAdView(ad);
                    }
                    else
                    {
                        Template.SetStyles(styles);
                        Template.SetNativeAd(ad);
                    }

                    Template.Visibility = ViewStates.Visible;
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                try
                {
                    Log.Debug("Google-Ads", "I_Ad AdMobNative Load Failed: " + p0.Message);

                    if (Template != null)
                        Template.Visibility = ViewStates.Gone;
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }
        }

        public static void Ad_AdMobNative(Activity context, TemplateView template = null)
        {
            try
            {
                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobNative)
                {
                    case true:
                        {
                            AdMobNative ads = new AdMobNative();
                            ads.ShowAd(context, template);
                            break;
                        }
                }
            }
            catch (Exception exception)
            {
                Methods.DisplayReportResultTrack(exception);
            }
        }

        #endregion

        #region Rewarded

        public class AdMobRewardedVideo : AnjoRewardedLoadCallback
        {
            private Activity Context;
            public void ShowAd(Activity context)
            {
                try
                {
                    Context = context;

                    AdRequest adRequest = new AdRequest.Builder().Build();
                    RewardedAd.Load(context, AppSettings.AdRewardVideoKey, adRequest, this);
                }
                catch (Exception exception)
                {
                    Methods.DisplayReportResultTrack(exception);
                }
            }

            public override void OnAdLoaded(RewardedAd p0)
            {
                try
                {
                    p0?.Show(Context, new MyUserEarnedRewardListener(Context));
                    base.OnAdLoaded(p0);
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                Log.Debug("Google-Ads", "I_Ad AdMobRewardedVideo Load Failed: " + p0.Message);
                base.OnAdFailedToLoad(p0);
            }
        }

        public static void Ad_RewardedVideo(Activity context)
        {
            try
            {
                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobRewardVideo)
                {
                    case true:
                        {
                            if (CountRewarded == AppSettings.ShowAdRewardedVideoCount)
                            {
                                CountRewarded = 0;
                                AdMobRewardedVideo ads = new AdMobRewardedVideo();
                                ads.ShowAd(context);
                            }
                            else
                            {
                                if (AppSettings.ShowFbInterstitialAds)
                                    AdsFacebook.InitInterstitial(context);
                                else if (AppSettings.ShowAppLovinInterstitialAds)
                                    AdsAppLovin.Ad_Interstitial(context);
                                else
                                    AdsColony.Ad_Interstitial(context);
                            }
                            break;
                        }
                    default:
                        if (AppSettings.ShowFbInterstitialAds)
                            AdsFacebook.InitInterstitial(context);
                        else if (AppSettings.ShowAppLovinInterstitialAds)
                            AdsAppLovin.Ad_Interstitial(context);
                        else
                            AdsColony.Ad_Interstitial(context);
                        break;
                }

            }
            catch (Exception exception)
            {
                Methods.DisplayReportResultTrack(exception);
            }
        }

        #endregion

        #region Banner

        public static void InitAdView(AdView mAdView, RecyclerView mRecycler)
        {
            try
            {
                switch (mAdView)
                {
                    case null:
                        return;
                }

                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobBanner)
                {
                    case true:
                        {
                            mAdView.Visibility = ViewStates.Visible;
                            var adRequest = new AdRequest.Builder();
                            mAdView.LoadAd(adRequest.Build());
                            mAdView.AdListener = new MyAdListener(mAdView, mRecycler);
                            break;
                        }
                    default:
                        {
                            mAdView.Pause();
                            mAdView.Visibility = ViewStates.Gone;
                            if (mRecycler != null) Methods.SetMargin(mRecycler, 0, 0, 0, 0);
                            break;
                        }
                }
            }
            catch (Exception e)
            {
                Methods.DisplayReportResultTrack(e);
            }
        }

        public static void LifecycleAdView(AdView mAdView, string lifecycle)
        {
            try
            {
                switch (mAdView)
                {
                    case null:
                        return;
                }

                if (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobBanner)
                {
                    switch (lifecycle)
                    {
                        case "Resume":
                            mAdView.Resume();
                            break;
                        case "Pause":
                            mAdView.Pause();
                            break;
                        case "Destroy":
                            mAdView.Destroy();
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                Methods.DisplayReportResultTrack(e);
            }
        }

        private class MyAdListener : AdListener
        {
            private readonly AdView MAdView;
            private readonly RecyclerView MRecycler;
            public MyAdListener(AdView mAdView, RecyclerView mRecycler)
            {
                MAdView = mAdView;
                MRecycler = mRecycler;
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                try
                {
                    Log.Debug("Google-Ads", "I_Ad AdView Load Failed: " + p0.Message);

                    MAdView.Visibility = ViewStates.Gone;
                    if (MRecycler != null) Methods.SetMargin(MRecycler, 0, 0, 0, 0);
                    base.OnAdFailedToLoad(p0);
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }


            public override void OnAdLoaded()
            {
                try
                {
                    MAdView.Visibility = ViewStates.Visible;

                    Resources r = Application.Context.Resources;
                    int px = (int)TypedValue.ApplyDimension(ComplexUnitType.Dip, MAdView.AdSize.Height, r.DisplayMetrics);
                    if (MRecycler != null) Methods.SetMargin(MRecycler, 0, 0, 0, px);

                    base.OnAdLoaded();
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }
        }

        #endregion

        #region Manager

        public static void InitAdManagerAdView(AdManagerAdView mAdView)
        {
            try
            {
                switch (mAdView)
                {
                    case null:
                        return;
                }

                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobBanner)
                {
                    case true:
                        {
                            mAdView.Visibility = ViewStates.Visible;
                            var adRequest = new AdManagerAdRequest.Builder();
                            mAdView.AdListener = new MyAdManagerAdViewListener(mAdView);
                            mAdView.LoadAd(adRequest.Build());
                            break;
                        }
                    default:
                        mAdView.Pause();
                        mAdView.Visibility = ViewStates.Gone;
                        break;
                }
            }
            catch (Exception e)
            {
                Methods.DisplayReportResultTrack(e);
            }
        }
        public static void LifecycleAdManagerAdView(AdManagerAdView mAdView, string lifecycle)
        {
            try
            {
                switch (mAdView)
                {
                    case null:
                        return;
                }

                if (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobBanner)
                {
                    switch (lifecycle)
                    {
                        case "Resume":
                            mAdView.Resume();
                            break;
                        case "Pause":
                            mAdView.Pause();
                            break;
                        case "Destroy":
                            mAdView.Destroy();
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                Methods.DisplayReportResultTrack(e);
            }
        }

        private class MyAdManagerAdViewListener : AdListener
        {
            private readonly AdManagerAdView MAdView;
            public MyAdManagerAdViewListener(AdManagerAdView mAdView)
            {
                MAdView = mAdView;
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                try
                {
                    Log.Debug("Google-Ads", "I_Ad AdManagerAdView Load Failed: " + p0.Message);

                    MAdView.Visibility = ViewStates.Gone;
                    base.OnAdFailedToLoad(p0);
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public override void OnAdLoaded()
            {
                try
                {
                    MAdView.Visibility = ViewStates.Visible;
                    base.OnAdLoaded();
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }
        }

        #endregion

        #region AppOpen

        public static void Ad_AppOpenManager(Activity context)
        {
            try
            {
                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobAppOpen)
                {
                    case true:
                        {
                            if (CountAppOpen == AppSettings.ShowAdAppOpenCount)
                            {
                                CountAppOpen = 0;

                                AppOpenManager appOpenManager = new AppOpenManager(context);
                                appOpenManager.ShowAdIfAvailable();
                            }
                            else
                            {
                                if (AppSettings.ShowFbInterstitialAds)
                                    AdsFacebook.InitInterstitial(context);
                                else if (AppSettings.ShowAppLovinInterstitialAds)
                                    AdsAppLovin.Ad_Interstitial(context);
                                else
                                    AdsColony.Ad_Interstitial(context);
                            }

                            CountAppOpen++;
                            break;
                        }
                    default:
                        if (AppSettings.ShowFbInterstitialAds)
                            AdsFacebook.InitInterstitial(context);
                        else if (AppSettings.ShowAppLovinInterstitialAds)
                            AdsAppLovin.Ad_Interstitial(context);
                        else
                            AdsColony.Ad_Interstitial(context);
                        break;
                }
            }
            catch (Exception exception)
            {
                Methods.DisplayReportResultTrack(exception);
            }
        }

        private class AppOpenManager : AnjoAppOpenLoadCallback
        {
            private readonly Activity MostCurrentActivity;
            private static AppOpenAd Ad;

            public AppOpenManager(Activity context)
            {
                try
                {
                    MostCurrentActivity = context;
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public void ShowAdIfAvailable()
            {
                try
                {
                    AdRequest request = new AdRequest.Builder().Build();
                    AppOpenAd.Load(MostCurrentActivity, AppSettings.AdAdMobAppOpenKey, request, this);
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public override void OnAdLoaded(AppOpenAd p0)
            {
                try
                {
                    base.OnAdLoaded(p0);

                    Ad = p0;
                    Ad.Show(MostCurrentActivity);
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                Log.Debug("Google-Ads", "I_Ad AppOpenManager Load Failed: " + p0.Message);
                base.OnAdFailedToLoad(p0);
            }

        }

        #endregion

        #region RewardedInterstitial

        public class AdMobRewardedInterstitial : AnjoRewardedInterstitialLoadCallback
        {
            private Activity Context;
            public void ShowAd(Activity context)
            {
                try
                {
                    Context = context;

                    AdRequest adRequest = new AdRequest.Builder().Build();

                    // Use an activity context to get the rewarded video instance. 
                    RewardedInterstitialAd.Load(context, AppSettings.AdRewardedInterstitialKey, adRequest, this);
                }
                catch (Exception exception)
                {
                    Methods.DisplayReportResultTrack(exception);
                }
            }

            public override void OnAdLoaded(RewardedInterstitialAd p0)
            {
                try
                {
                    p0?.Show(Context, new MyUserEarnedRewardListener(Context));
                    base.OnAdLoaded(p0);
                }
                catch (Exception exception)
                {
                    Methods.DisplayReportResultTrack(exception);
                }
            }

            public override void OnAdFailedToLoad(LoadAdError p0)
            {
                Log.Debug("Google-Ads", "I_Ad AdMobRewardedInterstitial Load Failed: " + p0.Message);
                base.OnAdFailedToLoad(p0);
            }
        }

        public static void Ad_RewardedInterstitial(Activity context)
        {
            try
            {
                switch (WoWonderTools.GetStatusAds() && AppSettings.ShowAdMobRewardedInterstitial)
                {
                    case true when CountRewardedInterstitial == AppSettings.ShowAdRewardedVideoCount:
                        {
                            if (CountRewardedInterstitial == AppSettings.ShowAdRewardedVideoCount)
                            {
                                CountRewardedInterstitial = 0;
                                AdMobRewardedInterstitial ads = new AdMobRewardedInterstitial();
                                ads.ShowAd(context);
                            }
                            else
                            {
                                if (AppSettings.ShowFbRewardVideoAds)
                                    AdsFacebook.InitRewardVideo(context);
                                else if (AppSettings.ShowAppLovinRewardAds)
                                    AdsAppLovin.Ad_Rewarded(context);
                                else
                                    AdsColony.Ad_Rewarded(context);
                            }
                            break;
                        }
                    default:
                        if (AppSettings.ShowFbRewardVideoAds)
                            AdsFacebook.InitRewardVideo(context);
                        else if (AppSettings.ShowAppLovinRewardAds)
                            AdsAppLovin.Ad_Rewarded(context);
                        else
                            AdsColony.Ad_Rewarded(context);
                        break;
                }
            }
            catch (Exception exception)
            {
                Methods.DisplayReportResultTrack(exception);
            }
        }

        #endregion

        private class MyUserEarnedRewardListener : Object, IOnUserEarnedRewardListener
        {
            private readonly Activity Activity;
            public MyUserEarnedRewardListener(Activity context)
            {
                Activity = context;
            }

            public void OnUserEarnedReward(IRewardItem rewardItem)
            {
                try
                {
                    // Handle the reward.
                    Console.WriteLine("The user earned the reward.");
                    int rewardAmount = rewardItem.Amount;
                    string rewardType = rewardItem.Type;

                    //if (!AppSettings.RewardedAdvertisingSystem)
                    //    return;

                    //if (!Methods.CheckConnectivity())
                    //    Toast.MakeText(Activity, Activity.GetString(Resource.String.Lbl_CheckYourInternetConnection), ToastLength.Short)?.Show();
                    //else
                    //{
                    //    PollyController.RunRetryPolicyFunction(new List<Func<Task>> { RequestsAsync.Advertise.AddAdMobPointAsync });
                    //    Toast.MakeText(Activity, Activity.GetString(Resource.String.Lbl_PointsAdded), ToastLength.Short)?.Show();
                    //}
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }
        }

        public static class InitializeAdsGoogle
        {
            public static void Initialize(Context context)
            {
                try
                {
                    if (AppSettings.ShowAdMobBanner || AppSettings.ShowAdMobInterstitial || AppSettings.ShowAdMobRewardVideo || AppSettings.ShowAdMobNative || AppSettings.ShowAdMobAppOpen || AppSettings.ShowAdMobRewardedInterstitial)
                    {
                        RequestConfiguration configuration = new RequestConfiguration.Builder().SetTestDeviceIds(new List<string>() { UserDetails.AndroidId }).Build();
                        MobileAds.RequestConfiguration = configuration;

                        MobileAds.Initialize(context, new MyInitializationCompleteListener());
                        MapsInitializer.Initialize(context);
                    }
                }
                catch (Exception e)
                {
                    Methods.DisplayReportResultTrack(e);
                }
            }

            private class MyInitializationCompleteListener : Object, IOnInitializationCompleteListener
            {
                public void OnInitializationComplete(IInitializationStatus p0)
                {

                }
            }
        }
    }
}