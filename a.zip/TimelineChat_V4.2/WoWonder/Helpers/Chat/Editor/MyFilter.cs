﻿using Android.Graphics;
using WoWonder.NiceArt.Models;

namespace WoWonder.Helpers.Chat.Editor
{
    public class MyFilter
    {
        public int Id { set; get; }
        public Bitmap NameImage { set; get; }
        public PhotoFilter PhotoFilter { set; get; }
    }
}