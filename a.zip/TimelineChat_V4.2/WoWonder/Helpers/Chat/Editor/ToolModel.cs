﻿namespace WoWonder.Helpers.Chat.Editor
{
    public class ToolModel
    {
        public string MToolName { get; set; }
        public string MToolIcon { get; set; }
        public ToolType MToolType { get; set; }
        public string MToolColor { get; set; }
    }
}