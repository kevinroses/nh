﻿namespace WoWonder.Helpers.Chat.Editor
{
    public class ColorPicker
    {
        public int Id { set; get; }
        public string ColorFirst { get; set; }
        public string ColorSecond { get; set; }
    }
}