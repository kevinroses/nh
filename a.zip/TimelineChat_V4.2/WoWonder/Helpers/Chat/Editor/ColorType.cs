﻿namespace WoWonder.Helpers.Chat.Editor
{
    public enum ColorType
    {
        ColorNormal,
        ColorGradient,
        ColorNormalAndGradient
    }
}