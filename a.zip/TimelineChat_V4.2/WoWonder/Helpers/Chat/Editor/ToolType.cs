﻿namespace WoWonder.Helpers.Chat.Editor
{
    public enum ToolType
    {
        Brush,
        Text,
        Eraser,
        Filter,
        FilterColor,
        Emojis,
        Sticker,
        Image,
        Color,
        CropImage,
    }
}